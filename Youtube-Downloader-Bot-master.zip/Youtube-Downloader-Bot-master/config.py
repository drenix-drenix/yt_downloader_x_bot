import  os

BOT_TOKEN = os.environ.get("5642558950:AAF84TmOZhQb6VBCO-gezwKRAt_I0sNEoGw")
APP_ID = int(os.environ.get("18205337"))
API_HASH = os.environ.get("811f1c33307e74726e6464b040b5a964")

youtube_next_fetch = 0  # time in minute


EDIT_TIME = 5