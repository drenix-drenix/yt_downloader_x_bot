# Youtube Dl bot 😉
## Prerequisite
    ffmpeg
  
    
## install dependencies
    pip3 install -r requirements.txt


## Setup Bot
    - Change configuration config.py  File
    - install dependencies
    - python3 -m bot
    
## Thanks ❤️
* [Spechide](https://telegram.dog/SpEcHIDe) for his [AnyDlBot](https://github.com/SpEcHiDe/AnyDLBot)
* [HasibulKabir](https://telegram.dog/HasibulKabir)

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/aryanvikash/Youtube-Downloader-Bot/tree/master)